# Odoo MINIO Storage Module

This module allows Odoo to store images in MINIO instead of the database, providing a more efficient way to manage file storage. It includes configuration settings for MINIO and tools for migrating existing images from the database to MINIO.

## Features

- Store images in MINIO, a high-performance object storage service.
- Configuration settings for MINIO, including server URL, access key, secret key, and bucket name.
- Migration process to transfer images from the database to MINIO without breaking existing links.
- Separate buttons for synchronizing images and deleting them from the database after migration.

## Installation

1. Clone the repository or download the module files.
2. Place the `odoo_minio_storage` directory in your Odoo addons path.
3. Update the app list in Odoo.
4. Install the module from the Odoo apps interface.

## Configuration

After installing the module, navigate to the settings page to configure MINIO:

- Enter the MINIO server URL.
- Provide the access key and secret key.
- Specify the bucket name where images will be stored.

## Usage

- Use the "Migrate Images" button to transfer images from the database to MINIO.
- Use the "Synchronize Images" button to ensure that all images are up-to-date in MINIO and remove them from the database if needed.

## Future Enhancements

This module is designed to be extensible. Future updates may include:

- Support for additional file types.
- Enhanced error handling during migration.
- Integration with other Odoo modules for seamless file management.

## License

This module is licensed under the terms of the Odoo Proprietary License.