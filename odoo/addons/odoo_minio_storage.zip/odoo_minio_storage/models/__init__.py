from . import ir_binary
from . import ir_attachment
from . import res_config_settings
from ..wizards import minio_migration