from odoo import models, fields, api
import base64
import logging
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

class MinioMigration(models.TransientModel):
    _name = 'minio.migration'
    _description = 'MinIO Storage Migration Tool'

    def action_migrate_images(self):
        """Migrates images from database to MinIO storage"""
        if not self.env['ir.config_parameter'].sudo().get_param('odoo_minio_storage.minio_is_active'):
            raise UserError("MinIO storage is not active. Please enable it in settings first.")

        attachment_model = self.env['ir.attachment']
        attachments = attachment_model.search([
            ('type', '=', 'binary'),
            ('store_fname', '!=', False),
            ('db_datas', '!=', False)
        ])

        migrated = 0
        failed = 0

        for attachment in attachments:
            try:
                # Get the file content
                file_data = attachment.datas
                
                # Upload to MinIO
                self._upload_to_minio(attachment, file_data)
                
                _logger.info(f"Successfully migrated attachment ID {attachment.id}")
                migrated += 1
            except Exception as e:
                _logger.error(f"Failed to migrate attachment ID {attachment.id}: {str(e)}")
                failed += 1

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Migration Complete',
                'message': f'Successfully migrated {migrated} files to MinIO. Failed: {failed}',
                'sticky': False,
                'type': 'success' if failed == 0 else 'warning',
            }
        }

    def action_cleanup_db_images(self):
        """Removes images from database after confirming they exist in MinIO"""
        if not self.env['ir.config_parameter'].sudo().get_param('odoo_minio_storage.minio_is_active'):
            raise UserError("MinIO storage is not active. Please enable it in settings first.")

        attachment_model = self.env['ir.attachment']
        attachments = attachment_model.search([
            ('type', '=', 'binary'),
            ('store_fname', '!=', False),
            ('db_datas', '!=', False)
        ])

        cleaned = 0
        failed = 0

        for attachment in attachments:
            try:
                # Check if file exists in MinIO
                if self._file_exists_in_minio(attachment):
                    # Clear the database data but keep the attachment record
                    attachment.write({'db_datas': False})
                    cleaned += 1
                else:
                    failed += 1
            except Exception as e:
                _logger.error(f"Failed to clean attachment ID {attachment.id}: {str(e)}")
                failed += 1

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Cleanup Complete',
                'message': f'Successfully cleaned {cleaned} files from database. Failed: {failed}',
                'sticky': False,
                'type': 'success' if failed == 0 else 'warning',
            }
        }

    def _upload_to_minio(self, attachment, data):
        """Upload file to MinIO"""
        from minio import Minio
        from minio.error import S3Error
        import io
        # Required for checksum calculation
        from odoo.tools import human_size, ustr, consteq, sql
        import hashlib

        # Get MinIO configuration
        server_url = self.env['ir.config_parameter'].sudo().get_param('odoo_minio_storage.minio_server_url')
        access_key = self.env['ir.config_parameter'].sudo().get_param('odoo_minio_storage.minio_access_key')
        secret_key = self.env['ir.config_parameter'].sudo().get_param('odoo_minio_storage.minio_secret_key')
        bucket_name = self.env['ir.config_parameter'].sudo().get_param('odoo_minio_storage.minio_bucket_name')

        # Create MinIO client
        client = Minio(
            server_url,
            access_key=access_key,
            secret_key=secret_key,
            secure=False
        )

        # Create bucket if it doesn't exist
        if not client.bucket_exists(bucket_name):
            client.make_bucket(bucket_name)

        # Convert base64 data to bytes
        binary_data = base64.b64decode(data)
        
        # Calculate checksum
        checksum = hashlib.sha1(binary_data).hexdigest()
        
        # Generate object name using checksum (consistent with _file_write_minio)
        object_name = f"images/{checksum}" 
        
        # Upload file
        client.put_object(
            bucket_name,
            object_name,
            io.BytesIO(binary_data),
            length=len(binary_data),
            content_type=attachment.mimetype or 'application/octet-stream'
        )
        
        # Update attachment with MinIO URL and checksum-based store_fname
        minio_url = f"minio://{bucket_name}/{object_name}"
        attachment.write({
            'url': minio_url,
            'store_fname': object_name, # Now uses images/checksum
            'checksum': checksum,       # Update checksum if Odoo's is different
            'file_size': len(binary_data),
            'db_datas': False, # Ensure db_datas is set to False
            'type': 'binary'
        })
        
        return minio_url

    def _file_exists_in_minio(self, attachment):
        """Check if file exists in MinIO"""
        from minio import Minio
        from minio.error import S3Error

        # Get MinIO configuration
        server_url = self.env['ir.config_parameter'].sudo().get_param('odoo_minio_storage.minio_server_url')
        access_key = self.env['ir.config_parameter'].sudo().get_param('odoo_minio_storage.minio_access_key')
        secret_key = self.env['ir.config_parameter'].sudo().get_param('odoo_minio_storage.minio_secret_key')
        bucket_name = self.env['ir.config_parameter'].sudo().get_param('odoo_minio_storage.minio_bucket_name')

        # Parse the URL to get the object name
        if not attachment.url or not attachment.url.startswith('minio://'):
            return False
            
        object_name = attachment.url.replace(f'minio://{bucket_name}/', '')
        
        # Create MinIO client
        client = Minio(
            server_url,
            access_key=access_key,
            secret_key=secret_key,
            secure=False
        )

        try:
            # Check if object exists
            client.stat_object(bucket_name, object_name)
            return True
        except S3Error:
            return False