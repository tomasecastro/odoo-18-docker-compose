import logging
from odoo import models, fields
from odoo.addons.base.models.ir_binary import IrBinary
from odoo.http import Stream

_logger_ir_binary = logging.getLogger(__name__ + ".IrBinaryCustom")

class IrBinaryCustom(models.AbstractModel):
    _inherit = 'ir.binary'

    def _record_to_stream(self, record, field_name):
        # Intentar obtener el ir.attachment real, especialmente para campos de imagen
        actual_attachment_record = None
        original_record_is_attachment = isinstance(record, models.BaseModel) and record._name == 'ir.attachment'

        if original_record_is_attachment:
            # Si el 'record' ya es un ir.attachment, usarlo directamente.
            # Esto sucede si _get_stream_from ya encontró el adjunto y nos llamó con él.
            actual_attachment_record = record
            # En este caso, field_name debería ser 'datas' o similar si se llama desde _get_stream_from
            # Si se llama directamente con un ir.attachment y otro field_name, podría ser un caso diferente.
            # Por seguridad, solo procederemos si field_name es 'datas' o si la URL es de MinIO.
            # La condición de la URL se verificará más abajo.
            _logger_ir_binary.debug(f"IrBinaryCustom: _record_to_stream called directly with ir.attachment ID {record.id}, field_name: {field_name}")

        elif record and hasattr(record, '_fields') and field_name in record._fields:
            # Si 'record' no es un ir.attachment, verificar si field_name es un campo binario
            # que Odoo asociaría con un ir.attachment.
            field_obj = record._fields[field_name]
            if field_obj.type == 'binary' and field_obj.attachment:
                # Este es el caso típico para campos como image_1920, image_128, etc.
                # Odoo usa _get_attachment para encontrar el ir.attachment asociado.
                # El método _get_attachment no es público, pero podemos intentar una búsqueda similar
                # o confiar en que si llegamos aquí, el super() lo haría.
                # Para ser más directos, intentamos buscar el adjunto nosotros mismos.
                # El dominio exacto que usa Odoo puede ser complejo, pero un básico es:
                domain = [
                    ('res_model', '=', record._name),
                    ('res_id', '=', record.id),
                    ('res_field', '=', field_name)
                ]
                attachment_found = self.env['ir.attachment'].search(domain, limit=1)
                if attachment_found:
                    actual_attachment_record = attachment_found
                    _logger_ir_binary.debug(f"IrBinaryCustom: Found attachment ID {attachment_found.id} for {record} field {field_name}")
                else:
                    _logger_ir_binary.debug(f"IrBinaryCustom: No attachment found via search for {record} field {field_name}. Will fall back to super.")
            else:
                _logger_ir_binary.debug(f"IrBinaryCustom: Field {field_name} on {record} is not a binary with attachment=True. Will fall back to super.")
        else:
            _logger_ir_binary.debug(f"IrBinaryCustom: Record or field_name not suitable for direct attachment handling. Will fall back to super.")


        if actual_attachment_record:
            attachment_url = getattr(actual_attachment_record, 'url', False)
            if attachment_url and attachment_url.startswith('minio://'):
                _logger_ir_binary.info(f"IrBinaryCustom: Detected MinIO URL '{attachment_url}' for attachment ID {actual_attachment_record.id}. Using custom read.")
                store_fname = actual_attachment_record.store_fname
                if store_fname:
                    try:
                        # Llamar a _file_read del ir.attachment.
                        # self.env['ir.attachment'].browse(actual_attachment_record.id) es redundante si ya tenemos el recordset.
                        file_content_bytes = actual_attachment_record._file_read(store_fname)
                        if file_content_bytes:
                            _logger_ir_binary.info(f"IrBinaryCustom: Successfully read {len(file_content_bytes)} bytes via _file_read for MinIO attachment ID {actual_attachment_record.id}")
                            # Ajustar la creación del Stream
                            return Stream(
                                type='data',  # Asegúrate de que esta línea esté presente
                                data=file_content_bytes,
                                mimetype=actual_attachment_record.mimetype,
                                download_name=actual_attachment_record.name,
                                # Opcionalmente, puedes añadir 'last_modified' y 'etag' si los tienes
                                # last_modified=actual_attachment_record.write_date,
                                # etag=actual_attachment_record.checksum,
                            )
                        else:
                            _logger_ir_binary.warning(f"IrBinaryCustom: _file_read for MinIO attachment ID {actual_attachment_record.id} (fname: {store_fname}) returned no data.")
                            # No llamar a super() aquí si se supone que está en MinIO y no se encontró.
                            # Devolver None o un stream vacío podría ser una opción, o dejar que falle.
                            # Para consistencia con el error anterior, no hacer nada aquí dejará que el flujo
                            # caiga al super() de abajo si este bloque no retorna.
                            # Sin embargo, si estamos seguros de que DEBERÍA estar en MinIO, no deberíamos llamar a super().
                            # Vamos a retornar None para indicar que no se pudo generar el stream desde MinIO.
                            # El controlador /web/image podría entonces devolver un 404 o una imagen placeholder.
                            return None # O un stream vacío: Stream.from_content(b'', mimetype='application/octet-stream')
                    except Exception as e:
                        _logger_ir_binary.error(f"IrBinaryCustom: Error reading MinIO attachment ID {actual_attachment_record.id} via _file_read: {e}", exc_info=True)
                        # Es importante que si hay un error aquí, no caigamos en el super() si el archivo DEBERÍA estar en MinIO.
                        # Retornar None es una forma de indicarle al controlador que no se pudo generar el stream.
                        return None # Error al leer desde MinIO
                else:
                    _logger_ir_binary.warning(f"IrBinaryCustom: MinIO attachment ID {actual_attachment_record.id} has MinIO URL but no store_fname. Cannot read.")
                    return None # No se puede leer sin store_fname
            else:
                # Tiene un adjunto, pero no es una URL de MinIO, dejar que super() lo maneje.
                _logger_ir_binary.debug(f"IrBinaryCustom: Attachment ID {actual_attachment_record.id} found, but URL '{attachment_url}' is not MinIO. Falling back to super.")
        
        # Si no es un adjunto de MinIO o no se pudo manejar arriba, usar la lógica original
        _logger_ir_binary.debug(f"IrBinaryCustom: Falling back to super()._record_to_stream for original record {record}, field {field_name}")
        return super()._record_to_stream(record, field_name)