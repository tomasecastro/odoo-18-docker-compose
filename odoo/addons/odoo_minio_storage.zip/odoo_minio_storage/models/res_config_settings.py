from odoo import models, fields, api

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    odoo_minio_storage_active = fields.Boolean(
        string='Use MinIO Storage (Specific)', 
        config_parameter='odoo_minio_storage.active'
    )
    odoo_minio_storage_url = fields.Char(
        string='MinIO Server URL (Specific)', 
        config_parameter='odoo_minio_storage.url'
    )
    odoo_minio_storage_access_key = fields.Char(
        string='MinIO Access Key (Specific)', 
        config_parameter='odoo_minio_storage.access_key'
    )
    odoo_minio_storage_secret_key = fields.Char(
        string='MinIO Secret Key (Specific)', 
        config_parameter='odoo_minio_storage.secret_key'
    )
    odoo_minio_storage_bucket_name = fields.Char(
        string='MinIO Bucket Name (Specific)', 
        config_parameter='odoo_minio_storage.bucket_name'
    )