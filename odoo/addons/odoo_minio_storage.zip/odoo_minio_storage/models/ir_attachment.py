from odoo import models, fields, api, _
import base64
import logging
import io

try:
    from minio import Minio
    from minio.error import S3Error
except ImportError:
    Minio = None
    S3Error = None
    _logger_init = logging.getLogger(__name__) 
    _logger_init.warning("La librería 'minio' no está instalada. El almacenamiento en MinIO no funcionará.")

_logger = logging.getLogger(__name__)

class IrAttachment(models.Model):
    _inherit = 'ir.attachment'

    def _get_minio_config(self):
        """Obtiene la configuración de MinIO desde los parámetros del sistema."""
        params = self.env['ir.config_parameter'].sudo()
        config_values = {
            'server_url': params.get_param('odoo_minio_storage.url'),
            'access_key': params.get_param('odoo_minio_storage.access_key'),
            'secret_key': params.get_param('odoo_minio_storage.secret_key'),
            'bucket_name': params.get_param('odoo_minio_storage.bucket_name'),
        }
        _logger.info(f"Odoo MinIO Storage (Specific) - MinIO Config loaded: {config_values}")
        return config_values

    def _is_minio_active(self):
        use_minio_param = self.env['ir.config_parameter'].sudo().get_param('odoo_minio_storage.active')
        return use_minio_param == 'True'

    def _get_minio_object_name(self, checksum):
        prefix = "images/" # O la lógica que uses para el nombre del objeto
        return f"{prefix}{checksum}"

    def _build_minio_url(self, config, object_name_in_minio):
        return f"minio://{config['bucket_name']}/{object_name_in_minio}"

    @api.model_create_multi
    def create(self, vals_list):
        # Si 'datas' está presente y MinIO está activo, preparamos los campos para MinIO
        if self._is_minio_active() and Minio:
            config = self._get_minio_config()
            if all(config.values()):
                for vals in vals_list:
                    if vals.get('datas'):
                        # El checksum se calculará más adelante en el flujo original de create/write
                        # No podemos calcularlo aquí fácilmente sin el 'value' decodificado.
                        # El _file_write será llamado, y necesitamos que store_fname se establezca.
                        # La URL la podemos intentar predecir si el checksum se pasa o se puede obtener.
                        # Sin embargo, es más seguro establecer la URL DESPUÉS de que _file_write_minio
                        # haya confirmado la subida y devuelto el store_fname.
                        # Este enfoque es complejo aquí.

                        # Un enfoque más simple es dejar que _file_write_minio haga el trabajo
                        # y luego, si es necesario, forzar una actualización si la URL no está.
                        # Pero el problema es que 'create' aún no tiene ID.
                        pass # La lógica de _file_write y _file_write_minio se encargará de la subida.
                           # El problema de la URL en create persiste con el enfoque actual de _file_write_minio.
        
        records = super().create(vals_list)

        # POST-CREATE: Intentar actualizar la URL si se usó MinIO y la URL no está.
        # Esto es una solución alternativa y puede tener implicaciones de rendimiento.
        if self._is_minio_active() and Minio:
            config = self._get_minio_config() # Recargar config por si acaso
            if all(config.values()):
                for record in records.filtered(lambda r: r.store_fname and r.store_fname.startswith("images/") and not r.url):
                    # Asumimos que si store_fname está y no hay URL, fue a MinIO por nuestro módulo.
                    # Y que store_fname es prefix + checksum
                    object_name_in_minio = record.store_fname 
                    new_url = self._build_minio_url(config, object_name_in_minio)
                    _logger.info(f"Odoo MinIO Storage (Specific) - Post-create/write URL update for attachment ID {record.id} to: {new_url}")
                    record.sudo().write({ # Usar sudo() si es necesario por permisos
                        'url': new_url,
                        'db_datas': False, # Asegurar que db_datas sea False
                        'type': 'binary'   # Asegurar que el tipo sea binary
                    })
        return records

    def write(self, vals):
        # Similar a create, si 'datas' cambia y MinIO está activo.
        # La llamada a super().write(vals) eventualmente llamará a _file_write.
        res = super().write(vals)

        # POST-WRITE: Similar al post-create.
        if self._is_minio_active() and Minio and ('datas' in vals or 'store_fname' in vals): # Solo si datas o store_fname cambió
            config = self._get_minio_config()
            if all(config.values()):
                for record in self.filtered(lambda r: r.store_fname and r.store_fname.startswith("images/") and not r.url):
                    object_name_in_minio = record.store_fname
                    new_url = self._build_minio_url(config, object_name_in_minio)
                    _logger.info(f"Odoo MinIO Storage (Specific) - Post-create/write URL update for attachment ID {record.id} to: {new_url}")
                    record.sudo().write({
                        'url': new_url,
                        'db_datas': False,
                        'type': 'binary'
                    })
        return res

    def _file_write(self, value, checksum):
        _logger.info(f"Odoo MinIO Storage (Specific) - _file_write called for checksum: {checksum}. Attachment IDs: {self.ids}")
        
        if self._is_minio_active():
            _logger.info("Odoo MinIO Storage - MinIO is active, attempting to use MinIO storage.")
            if not Minio:
                _logger.error("Odoo MinIO Storage - MinIO SDK (Minio class) not available. Cannot use MinIO storage. Please install 'minio' library.")
                return super()._file_write(value, checksum)
            
            # Llamar a _file_write_minio. Este método ahora NO debería hacer record.write()
            # sino devolver la información necesaria.
            # O, mantenemos _file_write_minio como está y confiamos en el post-create/write hook.
            # Por ahora, mantenemos _file_write_minio como está para la subida.
            # El store_fname devuelto por _file_write_minio será usado por el super().create/write.
            store_fname_from_minio = self._file_write_minio(value, checksum, for_create_or_update=True)
            
            # Si _file_write_minio tuvo éxito, devolvemos su store_fname.
            # El llamador (Odoo core) usará este store_fname.
            # Los campos 'db_datas': False, 'type': 'binary', 'url': new_url
            # se intentarán establecer en el post-create/write hook.
            return store_fname_from_minio
        else:
            _logger.info("Odoo MinIO Storage - MinIO is not active, using default Odoo storage.")
            return super()._file_write(value, checksum)
    
    # Modificar _file_write_minio para no hacer el self.write()
    def _file_write_minio(self, value, checksum, for_create_or_update=False):
        _logger.info(f"Odoo MinIO Storage (Specific) - _file_write_minio called for checksum: {checksum}")
        config = self._get_minio_config()
        
        if not all(config.values()):
            _logger.warning(f"Odoo MinIO Storage (Specific) - MinIO configuration is incomplete: {config}. Falling back to default storage.")
            # Si estamos en el flujo de _file_write, necesitamos devolver lo que super haría.
            # Esto es complicado porque no tenemos el 'value' original si _file_write lo llamó.
            # Es mejor que _file_write maneje el fallback completo.
            raise Exception("MinIO configuration incomplete. Fallback should be handled by caller.")

        _logger.info("Odoo MinIO Storage (Specific) - MinIO configuration seems complete.")
        
        object_name_in_minio = self._get_minio_object_name(checksum)
        _logger.info(f"Odoo MinIO Storage (Specific) - Determined MinIO object name: {object_name_in_minio}")
        
        current_mimetype = self[0].mimetype if self and self.ids else 'application/octet-stream'
        if not self.ids and for_create_or_update: # Si es llamado desde create, self puede no tener ID aún
             # Tratar de obtener mimetype de vals si es posible, o usar default.
             pass


        try:
            client = Minio(
                config['server_url'], access_key=config['access_key'],
                secret_key=config['secret_key'], secure=False
            )
            _logger.info(f"Odoo MinIO Storage (Specific) - Checking/Creating bucket: {config['bucket_name']}")
            if not client.bucket_exists(config['bucket_name']):
                client.make_bucket(config['bucket_name'])
                _logger.info(f"Odoo MinIO Storage - Bucket {config['bucket_name']} created.")
            else:
                _logger.info(f"Odoo MinIO Storage - Bucket {config['bucket_name']} already exists.")
            
            _logger.info(f"Odoo MinIO Storage (Specific) - Attempting to upload '{object_name_in_minio}' to bucket '{config['bucket_name']}'")
            client.put_object(
                config['bucket_name'], object_name_in_minio,
                io.BytesIO(value), length=len(value),
                content_type=current_mimetype
            )
            _logger.info(f"Odoo MinIO Storage (Specific) - Successfully uploaded '{object_name_in_minio}' to MinIO.")
            
            # YA NO HACEMOS EL WRITE AQUÍ. El post-create/write hook se encargará.
            # if self.ids and for_create_or_update: # Solo si es una actualización de un registro existente
            #     for record in self:
            #         new_url = self._build_minio_url(config, object_name_in_minio)
            #         _logger.info(f"Odoo MinIO Storage (Specific) - (DEPRECATED IN _file_write_minio) Updating URL for attachment ID {record.id} to: {new_url}")
            #         # record.write({'url': new_url, ...}) # NO HACER ESTO AQUÍ

            return object_name_in_minio
            
        except S3Error as e:
            _logger.error(f"Odoo MinIO Storage (Specific) - S3Error during MinIO write operation for '{object_name_in_minio}': {e}", exc_info=True)
            raise # Re-lanzar para que _file_write pueda hacer fallback
        except Exception as e:
            _logger.error(f"Odoo MinIO Storage (Specific) - Generic error during MinIO write operation for '{object_name_in_minio}': {e}", exc_info=True)
            raise # Re-lanzar

    def _file_read(self, fname):
        """Sobrescribe el método para leer desde MinIO cuando corresponde."""
        # fname es el store_fname, que debería ser 'images/checksum' si fue guardado por _file_write_minio
        _logger.info(f"Odoo MinIO Storage (Specific) - _file_read called for fname: '{fname}'. Attachment IDs: {self.ids}")

        # Es importante manejar 'self' correctamente, especialmente si puede ser un recordset vacío o múltiple.
        # Para leer, usualmente se opera sobre un solo adjunto a la vez.
        current_record = self[0] if self and self.ids else None
        current_record_url = current_record.url if current_record else None
        
        use_minio_param = self.env['ir.config_parameter'].sudo().get_param('odoo_minio_storage.active')
        use_minio_is_configured_active = (use_minio_param == 'True')
        
        # La URL debe indicar que este adjunto específico está en MinIO.
        is_minio_url_on_attachment = current_record_url and current_record_url.startswith('minio://')
        
        _logger.info(
            f"Odoo MinIO Storage (Specific) - _file_read checks: "
            f"use_minio_configured_active={use_minio_is_configured_active}, "
            f"fname_provided={bool(fname)}, "
            f"is_minio_url_on_attachment={is_minio_url_on_attachment} (URL: {current_record_url})"
        )

        if use_minio_is_configured_active and fname and is_minio_url_on_attachment:
            _logger.info(f"Odoo MinIO Storage (Specific) - Conditions met. Attempting to read '{fname}' from MinIO.")
            if not Minio:
                _logger.error("Odoo MinIO Storage (Specific) - MinIO SDK (Minio class) not available for reading. Falling back to default storage.")
                return super()._file_read(fname)
            try:
                # 'fname' (store_fname) es el object_name_in_minio
                data = self._file_read_minio(fname) 
                if data:
                    _logger.info(f"Odoo MinIO Storage (Specific) - Successfully retrieved {len(data)} bytes for '{fname}' from MinIO.")
                else:
                    _logger.warning(f"Odoo MinIO Storage (Specific) - Retrieved no data for '{fname}' from MinIO (_file_read_minio returned None/empty).")
                return data # Retorna los datos leídos de MinIO
            except Exception as e:
                # _file_read_minio ya registra errores detallados si lanza una excepción.
                _logger.warning(f"Odoo MinIO Storage (Specific) - Failed to read '{fname}' from MinIO due to error: {e}. Attempting fallback to default storage.", exc_info=True)
                return super()._file_read(fname) # Fallback al almacenamiento por defecto
        else:
            _logger.info(f"Odoo MinIO Storage (Specific) - Not reading '{fname}' from MinIO (conditions not met or MinIO inactive). Using default Odoo storage.")
            return super()._file_read(fname)
    
    def _file_read_minio(self, object_name_in_minio):
        """Lee un archivo desde MinIO. object_name_in_minio es la ruta completa del objeto en el bucket (ej: 'images/checksum')."""
        _logger.info(f"Odoo MinIO Storage (Specific) - _file_read_minio called for object: '{object_name_in_minio}'")
        config = self._get_minio_config()

        # Validar configuración esencial para la lectura
        required_keys = ['server_url', 'access_key', 'secret_key', 'bucket_name']
        if not all(config.get(key) for key in required_keys):
            missing_keys = [key for key in required_keys if not config.get(key)]
            _logger.error(f"Odoo MinIO Storage (Specific) - MinIO configuration is incomplete for reading '{object_name_in_minio}'. Missing keys: {missing_keys}. Config: {config}")
            raise Exception(f"MinIO configuration incomplete for reading object '{object_name_in_minio}'. Missing: {missing_keys}")

        try:
            # Asumiendo que config['server_url'] es 'host:port' (ej: 'minio:9000')
            # y la conexión es HTTP, por lo tanto secure=False.
            # Si MinIO usa HTTPS, secure debería ser True y server_url no debería tener el esquema.
            client = Minio(
                config['server_url'],
                access_key=config['access_key'],
                secret_key=config['secret_key'],
                secure=False # Consistente con la configuración de escritura. Ajustar si MinIO usa HTTPS.
            )
            
            _logger.info(f"Odoo MinIO Storage (Specific) - Attempting to get object '{object_name_in_minio}' from bucket '{config['bucket_name']}' using server '{config['server_url']}' (secure: False)")
            response = client.get_object(config['bucket_name'], object_name_in_minio)
            data = response.read()
            # Es importante cerrar la conexión de la respuesta para liberar recursos.
            response.close()
            response.release_conn()

            if data:
                _logger.info(f"Odoo MinIO Storage (Specific) - Successfully read {len(data)} bytes for '{object_name_in_minio}' from MinIO bucket '{config['bucket_name']}'.")
            else:
                _logger.warning(f"Odoo MinIO Storage (Specific) - Read 0 bytes for '{object_name_in_minio}' from MinIO bucket '{config['bucket_name']}'. The object might be empty.")
            return data # Retorna los datos binarios del archivo
            
        except S3Error as e:
            _logger.error(f"Odoo MinIO Storage (Specific) - S3Error reading '{object_name_in_minio}' from MinIO (bucket: {config['bucket_name']}): {e}", exc_info=True)
            # Re-lanzar la excepción permite que el llamador (_file_read) la maneje (ej: fallback).
            raise
        except Exception as e:
            _logger.error(f"Odoo MinIO Storage (Specific) - Generic error reading '{object_name_in_minio}' from MinIO (bucket: {config['bucket_name']}): {e}", exc_info=True)
            # Re-lanzar la excepción.
            raise

    def unlink(self):
        if not self:
            return True

        # Identificar adjuntos almacenados en MinIO ANTES de eliminarlos de la BD
        minio_attachments_to_delete = []
        if self._is_minio_active() and Minio:
            config = self._get_minio_config()
            if all(config.values()):
                for record in self:
                    if record.url and record.url.startswith('minio://') and record.store_fname:
                        minio_attachments_to_delete.append({
                            'id': record.id,
                            'object_name': record.store_fname, # store_fname es el nombre del objeto en MinIO
                            'url': record.url
                        })
            else:
                _logger.warning("Odoo MinIO Storage (Specific) - MinIO configuration incomplete. Cannot process deletions from MinIO.")

        # Intentar eliminar de MinIO
        if minio_attachments_to_delete:
            try:
                client = Minio(
                    config['server_url'],
                    access_key=config['access_key'],
                    secret_key=config['secret_key'],
                    secure=False # Ajustar si MinIO usa HTTPS
                )
                bucket_name = config['bucket_name']
                
                objects_to_delete_minio = [att['object_name'] for att in minio_attachments_to_delete]
                
                if objects_to_delete_minio:
                    _logger.info(f"Odoo MinIO Storage (Specific) - Attempting to delete objects from MinIO bucket '{bucket_name}': {objects_to_delete_minio}")
                    # La API de MinIO para eliminar múltiples objetos espera una lista de objetos Minio.delete_object
                    # o puedes iterar y eliminar uno por uno.
                    # Iterar es más simple para el manejo de errores individuales si es necesario.
                    for att_info in minio_attachments_to_delete:
                        try:
                            client.remove_object(bucket_name, att_info['object_name'])
                            _logger.info(f"Odoo MinIO Storage (Specific) - Successfully deleted object '{att_info['object_name']}' (Attachment ID: {att_info['id']}) from MinIO bucket '{bucket_name}'.")
                        except S3Error as e:
                            _logger.error(f"Odoo MinIO Storage (Specific) - S3Error deleting object '{att_info['object_name']}' (Attachment ID: {att_info['id']}, URL: {att_info['url']}) from MinIO: {e}", exc_info=True)
                            # Decide si quieres que un fallo aquí impida el unlink en Odoo.
                            # Por ahora, solo logueamos y continuamos.
                        except Exception as e:
                            _logger.error(f"Odoo MinIO Storage (Specific) - Generic error deleting object '{att_info['object_name']}' (Attachment ID: {att_info['id']}, URL: {att_info['url']}) from MinIO: {e}", exc_info=True)


            except S3Error as e:
                _logger.error(f"Odoo MinIO Storage (Specific) - S3Error during MinIO client initialization or bulk delete setup: {e}", exc_info=True)
                # Podrías decidir no continuar con el unlink en Odoo si la conexión a MinIO falla catastróficamente.
            except Exception as e:
                _logger.error(f"Odoo MinIO Storage (Specific) - Generic error during MinIO client initialization or bulk delete setup: {e}", exc_info=True)

        # Proceder con la eliminación del registro en Odoo
        return super().unlink()

