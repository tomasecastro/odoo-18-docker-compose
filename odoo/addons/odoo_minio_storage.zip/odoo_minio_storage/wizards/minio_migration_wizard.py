from odoo import models, fields, api, _
from odoo.exceptions import UserError
import logging
import io
import os # Necesario para construir rutas de filestore si _file_read no es suficiente

_logger = logging.getLogger(__name__)

class MinioMigrationWizard(models.TransientModel):
    _name = 'minio.migration.wizard'
    _description = 'Wizard for migrating attachments from Odoo Filestore to MinIO'

    batch_size = fields.Integer(string="Batch Size", default=50, help="Number of attachments to process in each batch.")

    def _get_attachments_to_migrate(self):
        """
        Identifies attachments that are binary, likely stored in filestore, 
        and not already on MinIO.
        """
        domain = [
            ('type', '=', 'binary'),
            ('store_fname', '!=', False), # Crucial: solo los que tienen un store_fname (indicativo de filestore)
            ('db_datas', '=', False),     # Y que explícitamente no tengan datos en la BD
            '|', ('url', '=', False), ('url', 'not like', 'minio://%') # Que no tengan URL o no sea de MinIO
        ]
        # Podrías añadir un filtro para excluir los que ya tienen una URL http/https si no los quieres migrar
        # domain.append(('url', 'not like', 'http%'))
        return self.env['ir.attachment'].search(domain)

    def migrate_attachments_batch(self):
        _logger.info("Starting MinIO migration process from Odoo Filestore...")
        attachments_to_migrate = self._get_attachments_to_migrate()
        
        if not attachments_to_migrate:
            _logger.info("No attachments found to migrate from filestore.")
            raise UserError(_("No attachments found that need migration (binary, in filestore, and not already on MinIO)."))

        total_to_migrate = len(attachments_to_migrate)
        _logger.info(f"Found {total_to_migrate} attachments to migrate from filestore.")
        
        migrated_count = 0
        error_count = 0
        
        IrAttachment = self.env['ir.attachment']
        
        if not IrAttachment._is_minio_active(): # Usando el método de ir.attachment
            raise UserError(_("MinIO storage is not active in system parameters."))
        
        minio_config = IrAttachment._get_minio_config() # Usando el método de ir.attachment
        if not all(minio_config.values()):
            raise UserError(_("MinIO configuration is incomplete. Please check system parameters."))

        # Inicializar cliente MinIO una vez
        try:
            from minio import Minio
            from minio.error import S3Error
        except ImportError:
            _logger.error("MinIO library not installed.")
            raise UserError(_("MinIO library not installed on the server."))

        client = Minio(
            minio_config['server_url'],
            access_key=minio_config['access_key'],
            secret_key=minio_config['secret_key'],
            secure=False # Ajustar si es necesario
        )
        # Verificar/Crear bucket una vez
        try:
            if not client.bucket_exists(minio_config['bucket_name']):
                client.make_bucket(minio_config['bucket_name'])
                _logger.info(f"Bucket {minio_config['bucket_name']} created.")
        except S3Error as e:
            _logger.error(f"Error checking or creating bucket {minio_config['bucket_name']}: {e}")
            raise UserError(_(f"Could not access or create MinIO bucket: {e}"))


        for attachment in attachments_to_migrate:
            _logger.info(f"Processing attachment ID: {attachment.id}, Name: {attachment.name}, Store Fname: {attachment.store_fname}")
            try:
                if not attachment.store_fname: # Doble chequeo, aunque el domain debería cubrirlo
                    _logger.warning(f"Attachment ID: {attachment.id} has no store_fname. Skipping.")
                    continue

                # Leer el archivo desde el filestore de Odoo usando el método _file_read del propio adjunto
                # Este método ya maneja la lógica de encontrar el archivo en el filestore.
                binary_data = attachment._file_read(attachment.store_fname) 
                
                if not binary_data:
                    _logger.warning(f"Attachment ID: {attachment.id} (Store Fname: {attachment.store_fname}) could not be read from filestore or is empty. Skipping.")
                    error_count +=1 # Contar como error si no se puede leer
                    continue

                checksum = attachment.checksum
                if not checksum:
                    # Si el checksum no existe, Odoo lo calcula al leer si es necesario,
                    # pero para el nombre del objeto en MinIO es mejor tenerlo.
                    # Si realmente falta, podrías calcularlo aquí:
                    # checksum = IrAttachment._compute_checksum(binary_data)
                    # O simplemente usar el store_fname como base si el checksum no es crítico para tu nomenclatura de MinIO.
                    # Por ahora, asumimos que el checksum existe o que _get_minio_object_name puede manejarlo.
                    _logger.warning(f"Attachment ID: {attachment.id} is missing checksum. Object name in MinIO might be affected.")
                    # Si tu _get_minio_object_name DEPENDE del checksum, esto podría ser un problema.
                    # Por simplicidad, continuaremos, pero esto es un punto a revisar.
                    # Si el checksum es vital, deberías hacer:
                    # if not checksum:
                    #     _logger.error(f"Attachment ID: {attachment.id} is missing checksum. Cannot determine MinIO object name. Skipping.")
                    #     error_count += 1
                    #     continue


                # Usar el checksum existente para el nombre del objeto en MinIO
                # Si el checksum no está, _get_minio_object_name podría fallar o dar un nombre no deseado.
                # Es más seguro asegurarse de que el checksum exista.
                # El checksum original de Odoo se basa en el contenido.
                # Si el store_fname ya es el checksum (común en Odoo), podrías usar eso.
                # Por ahora, usaremos el checksum del registro.
                if not checksum: # Si después de leer, el checksum sigue sin estar (poco probable si el archivo existe)
                    _logger.error(f"Attachment ID: {attachment.id} still missing checksum after read. Skipping.")
                    error_count += 1
                    continue
                
                object_name_in_minio = IrAttachment._get_minio_object_name(checksum)
                
                client.put_object(
                    minio_config['bucket_name'],
                    object_name_in_minio,
                    io.BytesIO(binary_data),
                    len(binary_data),
                    content_type=attachment.mimetype or 'application/octet-stream'
                )
                _logger.info(f"Successfully uploaded '{object_name_in_minio}' to MinIO for attachment ID {attachment.id}.")

                new_url = IrAttachment._build_minio_url(minio_config, object_name_in_minio)
                update_vals = {
                    'url': new_url,
                    'store_fname': object_name_in_minio, # Actualizar store_fname para que coincida con MinIO
                    # 'db_datas' ya es False, no necesitamos cambiarlo.
                }
                attachment.sudo().write(update_vals)
                _logger.info(f"Attachment ID {attachment.id} successfully updated in Odoo to point to MinIO.")
                migrated_count += 1
                
                if migrated_count % self.batch_size == 0:
                    self.env.cr.commit()
                    _logger.info(f"Committed batch. Migrated so far: {migrated_count}")

            except FileNotFoundError:
                _logger.error(f"Error migrating attachment ID {attachment.id} (Name: {attachment.name}, Store Fname: {attachment.store_fname}): File not found in Odoo filestore.", exc_info=False) # No es necesario exc_info para FileNotFoundError
                error_count += 1
            except S3Error as e_minio:
                 _logger.error(f"MinIO S3Error migrating attachment ID {attachment.id} (Name: {attachment.name}): {str(e_minio)}", exc_info=True)
                 error_count += 1
            except Exception as e:
                _logger.error(f"Generic error migrating attachment ID {attachment.id} (Name: {attachment.name}): {str(e)}", exc_info=True)
                error_count += 1
        
        self.env.cr.commit() 
        _logger.info(f"Migration process from filestore finished. Migrated: {migrated_count}, Errors: {error_count}.")
        
        if error_count > 0:
            message = _(f"Migration (filestore) completed with {error_count} errors. Migrated {migrated_count} attachments successfully. Please check server logs.")
        else:
            message = _(f"Migration (filestore) completed successfully. Migrated {migrated_count} attachments.")
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('MinIO Filestore Migration'),
                'message': message,
                'sticky': True,
            }
        }

    def action_migrate_to_minio(self):
        self.ensure_one()
        return self.migrate_attachments_batch()