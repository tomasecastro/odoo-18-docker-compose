{
    "name": "Odoo MinIO Storage",
    "version": "1.0",
    "category": "Tools",
    "summary": "Module to store images in MinIO instead of the database.",
    "description": "This module allows Odoo to use MinIO for storing images, providing a configuration interface and migration tools.",
    "depends": ["base", "web"],
    "data": [
        "security/ir.model.access.csv",
        "views/res_config_settings_views.xml",
        "views/minio_migration_views.xml"
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
    "license": "LGPL-3",
    "images": ["static/description/icon.png"]
}